package com.pizza;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.pizza.Repository.CustomerRepository;
import com.pizza.Services.CustomerService;

@SpringBootTest
public class CustomerTest {

	@Autowired
	CustomerService customerservice;
	
	@Autowired
	CustomerRepository customerrepository;
	
	@Test
	void customerNotNull() {
		assertNotNull(customerservice.findallCustomer());
	}
	
	@Test
	
	void customerByidTest() {
		assertNotNull(customerservice.findbyidCustomer(1l));
	}
	
	@Test
	
	void customerCountTest() {
		assertEquals(8, customerrepository.count());
	}
	
	@Test
	void customerComparison() {
		assertNotEquals(customerservice.findbyidCustomer(1l),customerservice.findbyidCustomer(6l));
		
		}
}
