package com.pizza;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pizza.Repository.CustomerRepository;
import com.pizza.Repository.PizzatypeRepository;
import com.pizza.Services.CustomerService;

public class Pizzatype {

	@Autowired
	PizzatypeRepository pizzatypeRepository;
	
	@Autowired
	CustomerRepository customerrepository;
	
	@Test
	void customerNotNull() {
		assertNotNull(pizzatypeRepository.findAll());
	}
	
	@Test
	
	void customerByidTest() {
		assertNotNull(pizzatypeRepository.findById(33));
	}
	
	@Test
	
	void customerCountTest() {
		assertEquals(8, pizzatypeRepository.count());
	}
	
	@Test
	void customerComparison() {
		assertNotEquals(pizzatypeRepository.findById(3),pizzatypeRepository.findById(55));
		
		}
}
