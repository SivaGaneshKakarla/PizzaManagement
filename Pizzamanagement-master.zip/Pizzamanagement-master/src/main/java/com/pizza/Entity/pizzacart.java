package com.pizza.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class pizzacart {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long cartId;
	
	@ManyToOne
	@JoinColumn(name="pizzaid")
	Pizzatype pizza;
	
	@ManyToOne
	@JoinColumn(name="custid")
	Customer customer;
	
	
	public pizzacart(Pizzatype pizza, Customer customer, Integer quantity) {
		super();
		this.pizza = pizza;
		this.customer = customer;
		this.quantity = quantity;
	}

	private Double price;
	
	private Integer quantity;

	public pizzacart(Double price, Integer quantity) {
		super();
		this.price = price;
		this.quantity = quantity;
	}

	public Long getCartId() {
		return cartId;
	}

	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}

	public Pizzatype getPizza() {
		return pizza;
	}

	public void setPizza(Pizzatype pizza) {
		this.pizza = pizza;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public pizzacart() {
		super();
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "pizzacart [cartId=" + cartId + ", pizza=" + pizza + ", customer=" + customer + ", price=" + price
				+ ", quantity=" + quantity + "]";
	}

	
	
	



	
	
	

}
