package com.pizza.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Pizzatype {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer pizzaid;
	public Pizzatype() {
		super();
	}
	
	
	@OneToMany(mappedBy="pizza",cascade=CascadeType.ALL)
	private List<pizzacart> pizza=new ArrayList<pizzacart>();
	
	

	//@OneToMany(mappedBy="pizza", cascade=CascadeType.ALL)
	//private List<Order> orders =new ArrayList<Order>();
	
	
	public Pizzatype(String pizzaName, String ingredients, Double price,Long quantity) {
		super();
		
		this.pizzaName = pizzaName;
		this.ingredients = ingredients;
		this.price = price;
		this.quantity=quantity;
		
		
	}
	@Column(unique=true)
	private String pizzaName;
	
	private String ingredients;
	private Double price;
	
	private Long quantity;
	
	private String img;
	
	
	public String getImg() {
		return img;
	}


	public void setImg(String img) {
		this.img = img;
	}


	@Override
	public String toString() {
		return "Pizzatype [pizzaid=" + pizzaid + ", pizzaName=" + pizzaName + ", ingredients=" + ingredients
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}


	public Integer getPizzaid() {
		return pizzaid;
	}


	public void setPizzaid(Integer pizzaid) {
		this.pizzaid = pizzaid;
	}


	public String getPizzaName() {
		return pizzaName;
	}


	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}


	public String getIngredients() {
		return ingredients;
	}


	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Long getQuantity() {
		return quantity;
	}


	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	
	

}