package com.pizza.Entity;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long orderid;
	
	@CreationTimestamp
	private  LocalDate date;
	private Double totalprice;
	private String orderstatus;
	
	private Long orderquantity;

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	//	
	@ManyToOne
	@JoinColumn(name="custid")
	private Customer customer;
	
	//@ManyToOne
	//@JoinColumn(name="adm_id")
	//private Admin adm;
//	
//	@OneToMany(mappedBy="fooditems")
//	private List<Pizzatype> pizza;
//	public long getOrderid() {
//		return orderid;
	
	
	//@ManyToOne
	//@JoinColumn(name="pizzaid")
	//private Pizzatype pizza; 
	
	private String Trackingid;

	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", date=" + date + ", totalprice=" + totalprice + ", orderstatus="
				+ orderstatus + ", orderquantity=" + orderquantity + ", customer=" + customer + ", Trackingid="
				+ Trackingid + "]";
	}

	public Order(LocalDate date, Double totalprice, String orderstatus, Long orderquantity, Customer customer,
			String trackingid) {
		super();
		this.date = date;
		this.totalprice = totalprice;
		this.orderstatus = orderstatus;
		this.orderquantity = orderquantity;
		this.customer = customer;
		Trackingid = trackingid;
	}

	public Long getOrderid() {
		return orderid;
	}

	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Double getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}

	public String getOrderstatus() {
		return orderstatus;
	}

	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}

	public Long getOrderquantity() {
		return orderquantity;
	}

	public void setOrderquantity(Long orderquantity) {
		this.orderquantity = orderquantity;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getTrackingid() {
		return Trackingid;
	}

	public void setTrackingid(String trackingid) {
		Trackingid = trackingid;
	}
}
			
	