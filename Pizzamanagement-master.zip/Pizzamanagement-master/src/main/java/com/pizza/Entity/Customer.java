package com.pizza.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name="customer")
public class Customer {
	
	public Customer( String customername, String city, String email,String password) {
		super();
		
		this.customername = customername;
		this.city = city;
		this.email = email;
		this.password=password;
		
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long customerid;
	
	@Column
	private String customername;
	@Column
	private String city;
	
	
	@Column(unique=true)
	private String email;
	
	@Column
	private String password;
	
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customername=" + customername + ", city=" + city + ", email="
				+ email + ", password=" + password + ", orders=" + orders + "]";
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	@OneToMany(mappedBy="customer", cascade=CascadeType.ALL)
	private List<Order> orders =new ArrayList<Order>();
	
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL)
	private List<pizzacart> mypizza=new ArrayList<pizzacart>();
	
	
	public long getCustomerid() {
		return customerid;
	}
	
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	

}




	