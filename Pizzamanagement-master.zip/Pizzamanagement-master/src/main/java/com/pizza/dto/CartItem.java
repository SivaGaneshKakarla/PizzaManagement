package com.pizza.dto;

public class CartItem {
	
	private Integer productid;
	private String email;
	public String getEmail() {
		return email;
	}
	
	public Integer getProductid() {
		return productid;
	}
	public void setProductid(Integer productid) {
		this.productid = productid;
	}


}
