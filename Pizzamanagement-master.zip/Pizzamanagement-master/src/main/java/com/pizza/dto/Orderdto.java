package com.pizza.dto;

public class Orderdto {
	
	
}
