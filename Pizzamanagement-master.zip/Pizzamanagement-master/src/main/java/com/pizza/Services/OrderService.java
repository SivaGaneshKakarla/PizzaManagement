package com.pizza.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pizza.Entity.Order;
import com.pizza.Entity.Pizzatype;
import com.pizza.Entity.pizzacart;
import com.pizza.Exception.FieldException;
import com.pizza.Repository.CartRepository;
import com.pizza.Repository.CustomerRepository;
import com.pizza.Repository.OrderRepository;
import com.pizza.Repository.PizzatypeRepository;

@Service
public class OrderService implements OrderServiceInterface{

	@Autowired
	OrderRepository od;
	
	@Autowired
	PizzatypeRepository pz;
	
	@Autowired
	CustomerRepository cr;
	
	@Autowired
	CartRepository cn;
	
	@Autowired
	CustomerService sc;
	
	@Override
	public Order saveOrder(Order order) {
		// TODO Auto-generated method stub
//		Order save_order=od.save(order);
		
		Double TotalPrice=0.0;
		
		Integer quantity=0;
		
		Long totalQuantity=0L;
		
		
		
		//getting customer id from json object and saving it in cartitems list.
		
		List<pizzacart> cartItems = cn.findcartitemsbycust(order.getCustomer().getCustomerid());
		
		//finding the type of pizza using the pizzaid based on the customerid.
		
		for(pizzacart cart:cartItems) {
			
			
			
			//mypizza consists of all the pizza id's which are in the customer's cart
			
			Pizzatype mypizza=pz.findById(cart.getPizza().getPizzaid()).get();
			
			quantity=cart.getQuantity();
			
			
//			if(mypizza.getQuantity()>=cart.getQuantity()) {
//								totalQuantity+=cart.getQuantity();
//				
//				TotalPrice+=mypizza.getPrice()*cart.getQuantity();
				
			if (mypizza.getQuantity() >= quantity) {
					totalQuantity += quantity;
					TotalPrice += mypizza.getPrice() * quantity;
					mypizza.setQuantity((mypizza.getQuantity() - quantity));;
					pz.save(mypizza);
				} else {
					throw new FieldException("Sorry We are Running Out Of Stock ");
				}
	
				
//			mypizza.setQuantity(mypizza.getQuantity()-cart.getQuantity());
////				
//			pz.save(mypizza);
				cn.delete(cart);
			}
		
	
		order.setOrderstatus("Order placed");
		order.setOrderquantity(totalQuantity);
		order.setTotalprice(TotalPrice);
		
		order.setTrackingid("SHP-"+sc.findbyidCustomer(order.getCustomer().getCustomerid()).getCustomername()+order.getOrderquantity());
		
		//Setting the customerid in the order table using customer service object and obtaining the customer id object using the jason customer id
		order.setCustomer(sc.findbyidCustomer(order.getCustomer().getCustomerid()));
		
		
		Order orderPlaced=od.save(order);
			
		
		
		return orderPlaced;
	}

	@Override
	public Order updateOrder(Order order) {
		// TODO Auto-generated method stub
		Order update_order=od.save(order);
		return update_order;
	}

	@Override
	public void deleteOrder(Long id) {
		// TODO Auto-generated method stub
		od.deleteById(id);
	}

	@Override
	public List<Order> findall() {
		// TODO Auto-generated method stub
		
		List<Order>find_all=od.findAll();
		return find_all;
	}

	@Override
	public Order findbyid(Long id) {
		// TODO Auto-generated method stub
		
		Optional<Order> findby_id =od.findById(id);
		
		Order as=findby_id.get();
		return as;
		
	}

	@Override
	public List<Order> findcustomerbyid(Long id) {
		// TODO Auto-generated method stub
		List<Order> a=od.findorderbycust(id);
		return a;
	}
	
	
	


}
