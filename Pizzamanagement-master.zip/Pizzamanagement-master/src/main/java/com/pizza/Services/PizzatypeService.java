package com.pizza.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pizza.Entity.Pizzatype;
import com.pizza.Repository.PizzatypeRepository;

@Service
public class PizzatypeService implements PizzatypeServiceInterface{

	@Autowired
	PizzatypeRepository pz;
	
	
	@Override
	public Pizzatype savePizzatype(Pizzatype pizza) {
		// TODO Auto-generated method stub
		Pizzatype save_pizzatype=pz.save(pizza);
		return save_pizzatype;
	}

	
	@Override
	public Pizzatype updatePizzatype(Pizzatype pizza) {
		// TODO Auto-generated method stub
		Pizzatype update_pizzatype=pz.save(pizza);
		return update_pizzatype;
	}

	
	@Override
	public void deletePizzatype(Integer id)
		// TODO Auto-generated method stub
	
	{
		pz.deleteById(id);
		
	}
	
	//fetchs all values of Pizzatype entity

	@Override
	public List<Pizzatype> findallpizzatype(Pizzatype pizza) {
		// TODO Auto-generated method stub
		List<Pizzatype> fetchallbypizzatype=pz.findAll();
		return fetchallbypizzatype;
	}
	
	
	@Override

	public Pizzatype findbyidPizzatype(Integer id) {
		// TODO Auto-generated method stub
		Optional<Pizzatype> fetchpizzatypebyid=pz.findById(id);
		Pizzatype as=fetchpizzatypebyid.get();
		return as;
		 
	}


	@Override
	public Pizzatype getbyid(Integer id) {
		// TODO Auto-generated method stub
		Optional<Pizzatype> getbyid=pz.findById(id);
		Pizzatype a=getbyid.get();
		return a;
	}
	
	

	
}
