package com.pizza.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pizza.Entity.Customer;
import com.pizza.Entity.Pizzatype;
import com.pizza.Entity.pizzacart;
import com.pizza.Repository.CartRepository;
import com.pizza.Repository.CustomerRepository;
import com.pizza.Repository.PizzatypeRepository;
import com.pizza.dto.CartItem;

@Service
public class CartService implements CartServiceinterface {

	@Autowired
	CartRepository cd;

	@Autowired
	PizzatypeRepository pt;

	@Autowired
	CustomerRepository cr;

	pizzacart pz;


	
	@Override
	public void deletecart(Long id) {
		// TODO Auto-generated method stub
		

		cd.deleteById(id);

	}

	@Override
	public List<pizzacart> findbyid(Long id) {
		// TODO Auto-generated method stub

		List<pizzacart> list = cd.findcartitemsbycust(id);

//		pizzacart a=cd.save(findby_id);
		// return a;
		return list;
	}

	@Override
	public List<pizzacart> findall() {
		// TODO Auto-generated method stub
		List<pizzacart> mypizzalist = cd.findAll();

		return mypizzalist;
	}

	@Override
	public pizzacart createcart(pizzacart obj) {  //save method for the controller
		// TODO Auto-generated method stub

		
		List<pizzacart> cartlist = cd.findAll();
		
		if (cartlist != null) {
			for (pizzacart i : cartlist) {
				if (i.getCustomer().getCustomerid() == obj.getCustomer().getCustomerid()) {
					if (i.getPizza().getPizzaid() == obj.getPizza().getPizzaid()) {
					Double price = i.getPrice(); //cartprice

						Pizzatype p = pt.findById(obj.getPizza().getPizzaid()).get();
						Double unitprice = p.getPrice();
						i.setPrice(p.getPrice() * obj.getQuantity() + price);//setting price in the cart by adding the previous products price
						i.setQuantity(obj.getQuantity() + i.getQuantity()); //setting the quantity if the product is same and customer is same adding previous quantity 
						return cd.save(i); //saving the cart

					}
				}
			}
		}
		
		//if customer id and product id are not matching creating a new cart id

		Pizzatype pp = pt.findById(obj.getPizza().getPizzaid()).get();
		obj.setPrice(pp.getPrice() * obj.getQuantity());
		obj.setPizza(pp);
		obj.setCustomer(cr.findById(obj.getCustomer().getCustomerid()).get());
		pizzacart cart = cd.save(obj);

		return cart;

	}

	public List<pizzacart> createcartList(List<pizzacart> mypizza) {
		List<pizzacart> list = new ArrayList<>();
		for (pizzacart obj : mypizza) {
			List<pizzacart> cartlist = cd.findAll();
			if (cartlist != null) {
				for (pizzacart i : cartlist) {
					if (i.getCustomer().getCustomerid() == obj.getCustomer().getCustomerid()) {
						if (i.getPizza().getPizzaid() == obj.getPizza().getPizzaid()) {

							Double price = i.getPrice();

							Pizzatype p = pt.findById(obj.getPizza().getPizzaid()).get();
							Double unitprice = p.getPrice();
							i.setPrice(p.getPrice() * obj.getQuantity() + price);
							i.setQuantity(obj.getQuantity() + i.getQuantity());
							 list.add(cd.save(i));
                              
						}
					}
				}
				continue;
			}
           
			Pizzatype pp = pt.findById(obj.getPizza().getPizzaid()).get();
			obj.setPrice(pp.getPrice() * obj.getQuantity());
			obj.setPizza(pp);
			obj.setCustomer(cr.findById(obj.getCustomer().getCustomerid()).get());
			pizzacart cart = cd.save(obj);
			list.add(cart);
		}
		return list;
	}

//	@Override
//	public List<Pizzatype> deleteproduct(Long pizzaid) {
//		// TODO Auto-generated method stub
//		
//		List<Pizzatype>deletetheproduct=cd
//		return null;
//	}


	@Override
	public pizzacart updateCart(pizzacart obj) { 
						return cd.save(obj);
	}
}
