package com.pizza.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pizza.Entity.Customer;
import com.pizza.Exception.FieldAlreadyExist;
import com.pizza.Exception.FieldBadRequestException;
import com.pizza.Exception.FielderrorResponse;
import com.pizza.Repository.CustomerRepository;

@Service
public class CustomerService implements CustomerServiceInterface{

	@Autowired
	CustomerRepository cus;
	@Override
	public Customer saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		List<Customer>clist=cus.findAll();
		
		for(Customer customerRecord : clist) {
			if(customerRecord.getEmail().endsWith("@admin.com")) {
				throw new FieldBadRequestException("Signup with @admin.com domain is not allowed for users.");
			}
			if(customerRecord.getEmail().contains(customer.getEmail())) {
				throw new FieldAlreadyExist("User Already exists with this credentials");
			}
		}
		Customer save_customer=cus.save(customer);
		
		return save_customer;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Customer customer2 = cus.findById(customer.getCustomerid()).get();
		
		customer2.setCustomername(customer.getCustomername());
		customer2.setCity(customer.getCity());
		
		
		
		Customer update_customer=cus.save(customer2);
		return update_customer;
	}

	

	@Override
	public List<Customer> findallCustomer() {
		// TODO Auto-generated method stub
		
		List<Customer>find_all_customers=cus.findAll();
		return find_all_customers;
		
		
		
	}

	@Override
	public Customer findbyidCustomer(Long id) {
		// TODO Auto-generated method stub
		Optional<Customer> cust=cus.findById(id);
		Customer as=cust.get();
		return as;
		
	}

	@Override
	public void deleteCustomer(Long id) {
		// TODO Auto-generated method stub
		
		cus.deleteById(id);
		
	}

	public Customer login(String email, String password) {
		// TODO Auto-generated method stub
		List<Customer> list = findallCustomer();
		for(Customer i:list) {
			if(i.getEmail().equals(email)&&i.getPassword().equals(password)) {
				return i;
			}
			
		}
		
			throw new FieldBadRequestException("Sorry Cannot find your email or password");
		
		
	}

	
	
	

}
