package com.pizza.Services;

import java.util.List;

import com.pizza.Entity.Customer;

public interface CustomerServiceInterface {
	
	public Customer saveCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public void deleteCustomer(Long id);
	public List<Customer> findallCustomer();
	public Customer findbyidCustomer(Long id);
	

}
