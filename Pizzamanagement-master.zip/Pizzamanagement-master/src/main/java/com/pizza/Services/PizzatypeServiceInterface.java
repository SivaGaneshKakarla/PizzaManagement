package com.pizza.Services;

import java.util.List;

import com.pizza.Entity.Pizzatype;

public interface PizzatypeServiceInterface {
	
	public Pizzatype savePizzatype(Pizzatype pizza);
	
	
	public Pizzatype updatePizzatype(Pizzatype pizza);
	
	public void deletePizzatype(Integer id);
	
	public List<Pizzatype> findallpizzatype(Pizzatype pizza);
	
	Pizzatype getbyid(Integer id);
	
	


	public Pizzatype findbyidPizzatype(Integer id);


	
	
	//public Pizzatype findbypizza_Name(String pizzaName);
	

}
