package com.pizza.Services;

import java.util.List;
import java.util.Optional;

import com.pizza.Entity.Pizzatype;
import com.pizza.Entity.pizzacart;
import com.pizza.dto.CartItem;

public interface CartServiceinterface {
	

	
	
	
	public void deletecart(Long id);
	
	public List<pizzacart> findbyid(Long id);
	
	public List<pizzacart> findall();
	
	public pizzacart createcart(pizzacart obj); 
	
//	public void  deleteproduct(Long pizzaid);
	
	public pizzacart updateCart(pizzacart obj) ;
	
}
