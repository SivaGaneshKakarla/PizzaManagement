package com.pizza.Services;

import java.util.List;

import com.pizza.Entity.Order;

public interface OrderServiceInterface {
	
	
	public Order updateOrder(Order order);
	
	public void deleteOrder(Long id);
	
	public List<Order> findall();
	//public Order calculateorder(Order order);
	public Order findbyid(Long id);

	Order saveOrder(Order order);
	
	public List<Order> findcustomerbyid(Long id);
	
	

}
