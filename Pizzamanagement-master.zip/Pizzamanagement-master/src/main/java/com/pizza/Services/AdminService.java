package com.pizza.Services;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.pizza.Entity.Admin;
import com.pizza.Repository.AdminRepository;

@Service
public class AdminService implements AdminServiceinterface {
	
	@Autowired
	AdminRepository ad;

	@Override
	public Admin saveAdmin(Admin admin) {
		
		// TODO Auto-generated method stub
		Admin added_admin=ad.save(admin);
		return added_admin;			
	}



	@Override
	public Admin findbyid(Long id) {
		// TODO Auto-generated method stub
		Optional<Admin> a=ad.findById(id);
		Admin as=a.get();
		return as;
	}

	@Override
	public List<Admin> findall() {
		List<Admin>a=ad.findAll();
		return a;
	}


	@Override
	public void deleteAdmin(Long id) {
		// TODO Auto-generated method stub
		ad.deleteById(id);	
	}
}
	
	