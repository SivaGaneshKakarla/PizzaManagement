package com.pizza.Services;

import java.util.List;

import com.pizza.Entity.Admin;

public interface AdminServiceinterface {
	
	public Admin saveAdmin(Admin admin);
	
//	public Admin saveAdmin(long id);
	
	public void deleteAdmin(Long id);
	
	public Admin findbyid(Long id);
	
	public List<Admin> findall();

}
