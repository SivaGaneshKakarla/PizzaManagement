package com.pizza.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.pizza.Entity.Order;
import com.pizza.Entity.Pizzatype;
import com.pizza.Entity.pizzacart;

public interface OrderRepository extends JpaRepository<Order, Long>{
	@Query(value="select * from orders where custid= :id",nativeQuery=true)
	List<Order> findorderbycust(long id);
	

}
