package com.pizza.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.pizza.Entity.pizzacart;

public interface CartRepository  extends JpaRepository<pizzacart, Long>{

	//public pizzacart save(Optional<pizzacart> findby_id);
	
	@Query(value="select * from pizzacart where custid= :id",nativeQuery=true)
	List<pizzacart> findcartitemsbycust(long id);
//
//	@Query(value="select*from pizzacart where ")
//	List<pizzacart> findByCustomer(long id);
	

}
