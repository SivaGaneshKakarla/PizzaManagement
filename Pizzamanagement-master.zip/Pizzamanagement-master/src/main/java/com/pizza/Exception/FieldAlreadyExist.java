package com.pizza.Exception;

public class FieldAlreadyExist extends RuntimeException  {
	
	public FieldAlreadyExist (String message) {
		
		super(message);
		
	}
}
