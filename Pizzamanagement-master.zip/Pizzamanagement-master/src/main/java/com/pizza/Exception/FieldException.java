package com.pizza.Exception;

public class FieldException extends RuntimeException{
	
	public FieldException(String message) {
		
		super(message);
	}

}
