package com.pizza.Exception;

public class FieldBadRequestException extends RuntimeException  {
	
	public  FieldBadRequestException (String message) {
		
		super(message);
		
	}
}
