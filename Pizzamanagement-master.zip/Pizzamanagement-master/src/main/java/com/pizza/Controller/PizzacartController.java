package com.pizza.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pizza.Entity.Customer;
import com.pizza.Entity.Pizzatype;
import com.pizza.Entity.pizzacart;
import com.pizza.Repository.CustomerRepository;
import com.pizza.Repository.PizzatypeRepository;
import com.pizza.Services.CartService;
import com.pizza.dto.CartItem;

@RestController
public class PizzacartController {
	
	@Autowired
	CartService pzz;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	PizzatypeRepository pizzatypeRepository;
	
	@CrossOrigin("http://localhost:4200/")
	@PostMapping("posttomycart")

	public pizzacart savecart(@RequestBody CartItem mypizza) {

		Customer customer=customerRepository.findByEmail(mypizza.getEmail());
		
//		
	Pizzatype pizzatype=pizzatypeRepository.findById(mypizza.getProductid()).get();
		
		pizzacart pizzacart=new pizzacart(pizzatype,customer,1);
		
		
		return pzz.createcart(pizzacart);
	}
	@CrossOrigin("http://localhost:4200/")
	@PostMapping("posttomycart/list")

	public List<pizzacart> savecartList(@RequestBody List<pizzacart> mypizza) {
		
		List<pizzacart> list =pzz.createcartList(mypizza);
		return list;
	}
	
	
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("getfrommycart")
	
	public List<pizzacart> fetchmycart() {
		
		return pzz.findall();
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("getfrommycart/{id}")
	public List<pizzacart> findbyid(@PathVariable Long id) {
		
		return pzz.findbyid(id);
	}
	
	@CrossOrigin("http://localhost:4200/")
	@DeleteMapping("Deletefrommycart/{id}")
	
	public String deletebyid(@PathVariable Long id) {
		
		pzz.deletecart(id);
		return null;
	}
	

	@CrossOrigin("http://localhost:4200/")
	@PutMapping("posttomycart")
	public pizzacart updatecart(@RequestBody pizzacart mypizza) {

		
		
		return pzz.updateCart(mypizza);
	}

	
}
