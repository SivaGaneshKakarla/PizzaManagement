package com.pizza.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pizza.Entity.Admin;
import com.pizza.Services.AdminService;
import com.pizza.Services.CustomerService;

@RestController
public class AdminController {
	
	@Autowired
	AdminService ab;
	@CrossOrigin("http://localhost:4200/")
	@PostMapping("postadmin")
	public Admin saveAdmin(@RequestBody Admin admin) {
		
		return ab.saveAdmin(admin);
			
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("getadmin")
	public List<Admin> getAdmin() {
		return ab.findall();
	}
	@CrossOrigin("http://localhost:4200/")
	@DeleteMapping("admin/{id}")
	public void deleteAdmin(@PathVariable Long id) {
		ab.deleteAdmin(id);
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("getadmin/{id}")
	
	public Admin getadminbyid(@PathVariable Long id) {
		return ab.findbyid(id);
	}
}
		
