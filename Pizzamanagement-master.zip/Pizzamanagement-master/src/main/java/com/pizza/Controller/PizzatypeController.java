package com.pizza.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pizza.Entity.Customer;
import com.pizza.Entity.Pizzatype;
import com.pizza.Services.CustomerService;
import com.pizza.Services.PizzatypeService;

@RestController
public class PizzatypeController {
	

	
	@Autowired
	PizzatypeService pz;
	@CrossOrigin("http://localhost:4200/")
	@PostMapping("pizzatype/product")
	
	public Pizzatype savepizzatype(@RequestBody Pizzatype pizza) {
		
		return pz.savePizzatype(pizza);
	}
	@CrossOrigin("http://localhost:4200/")
	@PutMapping("putpizzatype/{id}")
	
	public Pizzatype updatePizzatype(@RequestBody Pizzatype pizza) {
		
		return pz.updatePizzatype(pizza);
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("/pizzatype")
	
	public List<Pizzatype> fetchpizza(Pizzatype pizza) {
		
		return (List<Pizzatype>) pz.findallpizzatype(pizza);
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("/pizzatype/{id}")
	
	public Pizzatype fetchpizzabyid(@PathVariable Integer id) {
		return pz.findbyidPizzatype(id);
		
	}
	@CrossOrigin("http://localhost:4200/")
	@DeleteMapping("/deletepizzatype/{id}")
	
	public void deletePizzabyid(@PathVariable Integer id) {
		
		pz.deletePizzatype(id);
	}
	
	
}
