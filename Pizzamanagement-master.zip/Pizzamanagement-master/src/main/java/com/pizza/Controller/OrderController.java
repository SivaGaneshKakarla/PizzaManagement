package com.pizza.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pizza.Entity.Order;
import com.pizza.Services.OrderService;

@RestController
public class OrderController {

	@Autowired
	OrderService od;
	
	@CrossOrigin("http://localhost:4200/")
	@PostMapping("/orders")
	public Order saveorder(@RequestBody Order order) {
		return od.saveOrder(order);
		}
	
	@CrossOrigin("http://localhost:4200/")
	@PutMapping("/orders")

	public Order updateorder(Order order) {
		return od.updateOrder(order);
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("/orders")

	public List<Order> fetchorder(Order order) {
		return od.findall();
	}
	
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("/orders/{id}")

	public Order fetchorderbyid(@PathVariable Long id) {

		return od.findbyid(id);

	}
	
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("/custorder/{id}")
	public List<Order> findcustbyid(@PathVariable Long id) {
		
		return od.findcustomerbyid(id);
	}
	@CrossOrigin
	@DeleteMapping("/orders/{id}")

	public void deleteorder(@PathVariable Long id) {
		od.deleteOrder(id);
	}

}
