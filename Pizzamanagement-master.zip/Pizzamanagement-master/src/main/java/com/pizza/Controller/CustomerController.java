package com.pizza.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pizza.Entity.Customer;
import com.pizza.Services.CustomerService;
import com.pizza.dto.Login;



@RestController

public class CustomerController {
	
	@Autowired
	CustomerService custo;
	
	@CrossOrigin("http://localhost:4200/")
	@PostMapping("/customer123")
	
	public Customer savecustomer(@RequestBody Customer customer) {
		
		return custo.saveCustomer(customer);
	}
	@CrossOrigin("http://localhost:4200/")
	@PutMapping("putcustomer")
	
	public Customer updatecustomer(@RequestBody Customer customer) {
		
		return custo.updateCustomer(customer);
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("/customer/{id}")
	
	public List<Customer> fetchcustomer() {
		
		return custo.findallCustomer();
	}
	@CrossOrigin("http://localhost:4200/")
	@GetMapping("customerbyid/{id}")
	
	public Customer findbyidcustomer(@PathVariable Long id) {
		return custo.findbyidCustomer(id);
	}
	@CrossOrigin("http://localhost:4200/")
	@DeleteMapping("customer/{id}")
	
	public void deletebyidcustomer(@PathVariable Long id) {
		
		custo.deleteCustomer(id);	
	}
	@CrossOrigin("http://localhost:4200/")
	@PostMapping("/customer/login")
	public Customer login(@RequestBody Login log) {
		
		Customer login =custo.login(log.getEmail(),log.getPassword());
		return login;
	}
	
	
	

}
