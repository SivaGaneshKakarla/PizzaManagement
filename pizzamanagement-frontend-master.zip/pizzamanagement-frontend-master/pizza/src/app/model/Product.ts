export class Product{
     
    constructor(public pizzaName: string,public price: number,public quantity:number,
    public img:string,public pizzaid: number,public ingredients:string){}
}