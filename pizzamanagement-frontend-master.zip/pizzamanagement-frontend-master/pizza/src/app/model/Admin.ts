export class Admin{
     
    constructor(public admin_id:number,admin_name:string,password:string){}
}