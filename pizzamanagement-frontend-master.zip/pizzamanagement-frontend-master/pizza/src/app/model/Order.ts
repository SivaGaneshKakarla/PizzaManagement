import { Product } from "./Product";

export class Order{
     
    constructor( customerid:number,public pizza: Product
    ){}
}